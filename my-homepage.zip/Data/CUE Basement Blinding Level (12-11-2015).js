//CUE Basement Blinding Level (12-11-2015)
var lineinput=new Array()
lineinput[1]=["346.171","819762.742","813524.462","-5.663"]
lineinput[2]=["375.121","819754.54","813552.226","-5.663"]
