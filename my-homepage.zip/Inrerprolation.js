
var baseline=new Array()
for (i=1;i<lineinput.length;i++)
{
baseline[i]=[lineinput[i][0],lineinput[i][1],lineinput[i][2],lineinput[i][3]] 
}

alert("Alignment Loading Completed");